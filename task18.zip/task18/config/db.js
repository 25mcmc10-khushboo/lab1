const mysql = require("mysql2");

const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "risku",          // ⚠️ XAMPP me usually blank hota hai
  database: "productdb"  // ⚠️ name lowercase recommended
});

db.connect((err) => {
  if (err) {
    console.log("DB Error:", err.message);
  } else {
    console.log("Database Connected");
  }
});

module.exports = db;