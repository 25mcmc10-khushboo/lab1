const express = require("express");
const app = express();

app.use(express.json());

const productRoutes = require("./routes/productRoutes");
const authRoutes = require("./routes/authRoutes");

app.use("/api/products", productRoutes);
app.use("/api/auth", authRoutes);

app.listen(5000,()=>{
console.log("Server running on port 5000");
});
