const auth = require("../middleware/authMiddleware");
const express = require("express");
const router = express.Router();
const db = require("../config/db");

// GET all products (PUBLIC)
router.get("/", (req, res) => {
  db.query("SELECT * FROM products", (err, result) => {
    if (err) return res.status(500).json(err);
    res.json(result);
  });
});

// GET single product (PUBLIC)
router.get("/:id", (req, res) => {
  db.query(
    "SELECT * FROM products WHERE id=?",
    [req.params.id],
    (err, result) => {
      if (err) return res.status(500).json(err);
      res.json(result[0]);
    }
  );
});


//CREATE product (PROTECTED)
router.post("/", auth, (req, res) => {
  const { name, description, price, category } = req.body;

  db.query(
    "INSERT INTO products(name,description,price,category) VALUES(?,?,?,?)",
    [name, description, price, category],
    (err, result) => {
      if (err) return res.status(500).json(err);

      res.json({
        message: "Product Created",
        id: result.insertId
      });
    }
  );
});


// UPDATE product (PROTECTED)
router.put("/:id", auth, (req, res) => {
  const { name, description, price, category } = req.body;

  db.query(
    "UPDATE products SET name=?,description=?,price=?,category=? WHERE id=?",
    [name, description, price, category, req.params.id],
    (err, result) => {
      if (err) return res.status(500).json(err);

      res.json({
        message: "Product Updated"
      });
    }
  );
});


//  DELETE product (PROTECTED)
router.delete("/:id", auth, (req, res) => {
  db.query(
    "DELETE FROM products WHERE id=?",
    [req.params.id],
    (err, result) => {
      if (err) return res.status(500).json(err);

      res.json({
        message: "Product Deleted"
      });
    }
  );
});

module.exports = router;