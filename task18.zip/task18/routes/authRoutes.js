console.log("AUTH ROUTES LOADED");

const express = require("express");
const router = express.Router();
const jwt = require("jsonwebtoken");

// TEST ROUTE (first)
router.get("/test", (req, res) => {
  res.send("AUTH WORKING");
});

// LOGIN ROUTE
router.post("/login", (req, res) => {
  console.log("LOGIN HIT:", req.body);

  const { email, password } = req.body;

  if (email === "admin@gmail.com" && password === "1234") {
    const token = jwt.sign(
      { user: "admin" },
      "secretkey",
      { expiresIn: "1h" }
    );

    return res.json({ token });
  } else {
    return res.status(401).json({
      message: "Invalid Login"
    });
  }
});

module.exports = router;