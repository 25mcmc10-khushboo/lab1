const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// MySQL Connection Pool 
const db = mysql.createPool({
    host: "127.0.0.1",     
    user: "root",
    password: "risku",      
    database: "userdb"
});

// Test route (to check server)
app.get("/", (req, res) => {
    res.send("Server working ");
});


// GET all users
app.get("/users", (req, res) => {
    console.log("GET /users called");

    db.query("SELECT * FROM users", (err, result) => {
        if (err) {
            console.log("Error:", err);
            return res.status(500).json({ error: err.message });
        }
        res.json(result);
    });
});


// ADD user
app.post("/users", (req, res) => {
    const { name, email } = req.body;

    db.query(
        "INSERT INTO users (name, email) VALUES (?, ?)",
        [name, email],
        (err, result) => {
            if (err) {
                console.log(err);
                return res.status(500).json({ error: err.message });
            }
            res.json({ message: "User added successfully" });
        }
    );
});


// UPDATE user
app.put("/users/:id", (req, res) => {
    const { name, email } = req.body;
    const { id } = req.params;

    db.query(
        "UPDATE users SET name=?, email=? WHERE id=?",
        [name, email, id],
        (err, result) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ message: "User updated successfully" });
        }
    );
});


// DELETE user
app.delete("/users/:id", (req, res) => {
    const { id } = req.params;

    db.query("DELETE FROM users WHERE id=?", [id], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: "User deleted successfully" });
    });
});


// Start server
app.listen(5000, () => {
    console.log(" Server running on http://localhost:5000");
});